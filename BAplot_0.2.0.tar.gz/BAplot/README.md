
<!-- badges: start -->
  [![R-CMD-check](https://github.com/KonstantinLang/ggBA/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/KonstantinLang/ggBA/actions/workflows/R-CMD-check.yaml)
  [![pkgdown](https://github.com/KonstantinLang/ggBA/actions/workflows/pkgdown.yaml/badge.svg)](https://github.com/KonstantinLang/ggBA/actions/workflows/pkgdown.yaml)
  [![](https://img.shields.io/github/last-commit/KonstantinLang/ggBA.svg)](https://github.com/KonstantinLang/ggBA/commits/main)
<!-- badges: end -->

## Bland-Altman

A Bland-Altman plot is a method of data plotting used in analyzing the agreement between two different methods. It was popularised in medical statistics by J. Martin Bland and Douglas G. Altman. [[1]](#r1) [[2]](#r2)

For more details see https://en.wikipedia.org/wiki/Bland%E2%80%93Altman_plot

This package provides functions to plot Bland-Altman statistics based on {[ggplot2](https://github.com/tidyverse/ggplot2)} functionality.

## Installation

Make sure {remotes} is installed:

```r
install.packages(c("remotes"))
```

Install source package from this repo. 3<sup>rd</sup>-party packages required or suggested by {BAplot} will be installed and/or upgraded automatically.

```r
remotes::install_github("KonstantinLang/ggBA")
```

## CRAN pre-submission check

For a full local CRAN-style check (including manual/PDF checks), install system tools first:

- `pdflatex` (e.g. via TeX Live/TinyTeX)
- `qpdf`
- `tidy` (optional, for HTML validation notes)

Then run:

```sh
R CMD build .
R CMD check --as-cran BAplot_0.2.0.tar.gz
```

## Issue tracker

Report bugs etc. at https://github.com/KonstantinLang/ggBA/issues.

## References

<span id="r1">[1]</span>: Altman DG, Bland JM (1983). "Measurement in medicine: the analysis of method comparison studies". The Statistician. 32 (3): 307-317. doi:10.2307/2987937. JSTOR 2987937.  
<span id="r2">[2]</span>: Bland JM, Altman DG (1986). "Statistical methods for assessing agreement between two methods of clinical measurement" (PDF). Lancet. 327 (8476): 307-10. CiteSeerX 10.1.1.587.8931. doi:10.1016/S0140-6736(86)90837-8. PMID 2868172. S2CID 2844897
